const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Pizza = sequelize.define('Pizza', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  number: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    unique: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT
  },
  basePrice: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    field: 'base_price'
  },
  images: {
    type: DataTypes.ARRAY(DataTypes.STRING)
  },
  categoryId: {
    type: DataTypes.UUID,
    field: 'category_id',
    references: {
      model: 'pizza_categories',
      key: 'id'
    }
  },
  rating: {
    type: DataTypes.DECIMAL(2, 1),
    defaultValue: 0.0
  },
  isSpicy: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'is_spicy'
  },
  isVegetarian: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'is_vegetarian'
  },
  isBestseller: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'is_bestseller'
  },
  isAvailable: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
    field: 'is_available'
  },
  caloricContent: {
    type: DataTypes.INTEGER,
    field: 'caloric_content'
  },
  weight: {
    type: DataTypes.DECIMAL(10, 2)
  },
  preparationTime: {
    type: DataTypes.TIME,
    field: 'preparation_time'
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    field: 'created_at'
  },
  updatedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    field: 'updated_at'
  }
}, {
  tableName: 'pizza_details',
  timestamps: true
});

module.exports = Pizza;