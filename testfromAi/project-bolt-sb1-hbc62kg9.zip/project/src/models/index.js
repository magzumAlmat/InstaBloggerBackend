const Pizza = require('./Pizza');
const Ingredient = require('./Ingredient');

// Define the many-to-many relationship between Pizza and Ingredient
const PizzaIngredient = sequelize.define('PizzaIngredient', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  quantity: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 1
  }
}, {
  tableName: 'pizza_ingredients'
});

Pizza.belongsToMany(Ingredient, { through: PizzaIngredient });
Ingredient.belongsToMany(Pizza, { through: PizzaIngredient });

module.exports = {
  Pizza,
  Ingredient,
  PizzaIngredient
};