const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Ingredient = sequelize.define('Ingredient', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  description: {
    type: DataTypes.TEXT
  },
  weightPerPortion: {
    type: DataTypes.DECIMAL(10, 2),
    field: 'weight_per_portion'
  },
  isVegetarian: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'is_vegetarian'
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    field: 'created_at'
  }
}, {
  tableName: 'ingredients',
  timestamps: false
});

module.exports = Ingredient;