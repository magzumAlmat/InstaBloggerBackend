const express = require('express');
const pizzaRoutes = require('./pizzaRoutes');

const router = express.Router();

// Mount routes
router.use('/api/pizzas', pizzaRoutes);

module.exports = router;