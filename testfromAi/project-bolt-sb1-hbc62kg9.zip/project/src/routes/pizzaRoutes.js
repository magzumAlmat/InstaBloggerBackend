const express = require('express');
const router = express.Router();
const pizzaController = require('../controllers/pizzaController');

// GET /api/pizzas - Get all pizzas
router.get('/', pizzaController.getAllPizzas);

// GET /api/pizzas/:id - Get pizza by ID
router.get('/:id', pizzaController.getPizzaById);

// POST /api/pizzas - Create new pizza
router.post('/', pizzaController.createPizza);

// PUT /api/pizzas/:id - Update pizza
router.put('/:id', pizzaController.updatePizza);

// DELETE /api/pizzas/:id - Delete pizza
router.delete('/:id', pizzaController.deletePizza);

module.exports = router;