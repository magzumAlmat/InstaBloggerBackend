const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface) => {
    await queryInterface.createTable('pizza_ingredients', {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
      },
      pizza_id: {
        type: DataTypes.UUID,
        references: {
          model: 'pizza_details',
          key: 'id'
        },
        onDelete: 'CASCADE'
      },
      ingredient_id: {
        type: DataTypes.UUID,
        references: {
          model: 'ingredients',
          key: 'id'
        },
        onDelete: 'CASCADE'
      },
      quantity: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 1
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    });

    // Add composite unique constraint
    await queryInterface.addConstraint('pizza_ingredients', {
      fields: ['pizza_id', 'ingredient_id'],
      type: 'unique',
      name: 'pizza_ingredient_unique'
    });
  },

  down: async (queryInterface) => {
    await queryInterface.dropTable('pizza_ingredients');
  }
};