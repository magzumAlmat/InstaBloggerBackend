const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface) => {
    await queryInterface.createTable('pizza_details', {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
      },
      number: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        unique: true
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false
      },
      description: {
        type: DataTypes.TEXT
      },
      base_price: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
      },
      images: {
        type: DataTypes.ARRAY(DataTypes.STRING)
      },
      category_id: {
        type: DataTypes.UUID,
        references: {
          model: 'pizza_categories',
          key: 'id'
        }
      },
      rating: {
        type: DataTypes.DECIMAL(2, 1),
        defaultValue: 0.0
      },
      is_spicy: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      is_vegetarian: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      is_bestseller: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      is_available: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
      },
      caloric_content: {
        type: DataTypes.INTEGER
      },
      weight: {
        type: DataTypes.DECIMAL(10, 2)
      },
      preparation_time: {
        type: DataTypes.TIME
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    });
  },

  down: async (queryInterface) => {
    await queryInterface.dropTable('pizza_details');
  }
};