const { Pizza, Ingredient } = require('../models');

// Get all pizzas
const getAllPizzas = async (req, res) => {
  try {
    const pizzas = await Pizza.findAll({
      include: [{ model: Ingredient }]
    });
    res.json(pizzas);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get pizza by ID
const getPizzaById = async (req, res) => {
  try {
    const pizza = await Pizza.findByPk(req.params.id, {
      include: [{ model: Ingredient }]
    });
    if (!pizza) {
      return res.status(404).json({ error: 'Pizza not found' });
    }
    res.json(pizza);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Create new pizza
const createPizza = async (req, res) => {
  try {
    const pizza = await Pizza.create(req.body);
    
    // If ingredients are provided, associate them with the pizza
    if (req.body.ingredients && Array.isArray(req.body.ingredients)) {
      await pizza.setIngredients(req.body.ingredients);
    }
    
    // Fetch the created pizza with its ingredients
    const createdPizza = await Pizza.findByPk(pizza.id, {
      include: [{ model: Ingredient }]
    });
    
    res.status(201).json(createdPizza);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Update pizza
const updatePizza = async (req, res) => {
  try {
    const pizza = await Pizza.findByPk(req.params.id);
    if (!pizza) {
      return res.status(404).json({ error: 'Pizza not found' });
    }

    await pizza.update(req.body);

    // Update ingredients if provided
    if (req.body.ingredients && Array.isArray(req.body.ingredients)) {
      await pizza.setIngredients(req.body.ingredients);
    }

    // Fetch updated pizza with ingredients
    const updatedPizza = await Pizza.findByPk(pizza.id, {
      include: [{ model: Ingredient }]
    });

    res.json(updatedPizza);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Delete pizza
const deletePizza = async (req, res) => {
  try {
    const pizza = await Pizza.findByPk(req.params.id);
    if (!pizza) {
      return res.status(404).json({ error: 'Pizza not found' });
    }
    await pizza.destroy();
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  getAllPizzas,
  getPizzaById,
  createPizza,
  updatePizza,
  deletePizza
};